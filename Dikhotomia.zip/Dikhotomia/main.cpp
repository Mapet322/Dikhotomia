#include <cstring>
#include <cstdio>
#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif
using namespace std;
#include "varglob.h"
#include "funciones.h"

///Main:////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int main ( int argc, char** argv )
{
    bool salir = false;

    SDL_Surface *mainmenu = cargar_imagen("graphics\\menu\\mainmenu.bmp");
    SDL_Surface *background = cargar_imagen("graphics\\BRUT\\level.bmp");
    SDL_Surface *player = cargar_imagen("graphics\\BRUT\\fullspritesheetkurt.bmp");

    SDL_Rect kurt[22];

    if(iniciar() == false) {
        exit(1);
    }

    poner_superficie(0, 0, mainmenu, screen);

    SDL_Flip(screen);

    while(salir == false) {
        while(SDL_PollEvent(&event) && salir == false) {

            if(event.type == SDL_QUIT) {
                    salir = true;
                }

            if(event.type == SDL_KEYDOWN) {

                switch(event.key.keysym.sym) {
                    case SDLK_ESCAPE:
                                    salir = true;
                                    break;

                    case SDLK_LEFT:
                                    poner_superficie(0, 0, background, screen);
                                    poner_superficie(200, 150, player, screen);
                                    SDL_Flip(screen);
                                    break;

                    default:
                                    break;
                }
            }
        }
    }

    SDL_FreeSurface( mainmenu);
    SDL_FreeSurface( player);
    SDL_FreeSurface( background);
    SDL_Quit();

    return 0;
}
