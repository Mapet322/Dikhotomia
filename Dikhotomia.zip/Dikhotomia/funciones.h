#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void poner_superficie(int x, int y, SDL_Surface* source, SDL_Surface* destination) {
    SDL_Rect offset;
    offset.x = x;
    offset.y = y;

    SDL_BlitSurface(source, NULL, destination, &offset);
}

bool iniciar() {
    if(SDL_Init(SDL_INIT_EVERYTHING) == -1) {
        return false;
    }

    screen = SDL_SetVideoMode(RESX, RESY, 32, SDL_SWSURFACE);
    if(screen == NULL) {
        return false;
    }
    SDL_WM_SetCaption("Event test", NULL);

    return true;
}

SDL_Surface *cargar_imagen(char dir[50]) {
    SDL_Surface* imagen = NULL;

    imagen = SDL_LoadBMP(dir);

    if(imagen != NULL) {
        Uint32 colorkey = SDL_MapRGB(imagen->format, 0, 0, 0);
        SDL_SetColorKey(imagen, SDL_SRCCOLORKEY, colorkey);
    }

    return imagen;
}

void BRUT(){

}

void HARD(){

}

#endif // FUNCIONES_H_INCLUDED
