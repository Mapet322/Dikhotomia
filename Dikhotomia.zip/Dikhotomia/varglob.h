#ifndef VARGLOB_H_INCLUDED
#define VARGLOB_H_INCLUDED

const int RESX=960, RESY=540;
SDL_Surface* screen = NULL;
SDL_Event event;

#endif // VARGLOB_H_INCLUDED
