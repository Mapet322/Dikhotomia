#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif
#ifdef __APPLE__
#include <SDL/SDL.h>
#else
#include <SDL.h>
#endif
#include <SDL_image.h>
#include <cstring>
#include <cstdio>
#include <iostream>
using namespace std;
#include "varglob.h"
#include "clases.h"
#include "funciones.h"

int main ( int argc, char** argv )
{
    iniciarSDL();

    MENU();

    SDL_Quit();
    return 0;
}
