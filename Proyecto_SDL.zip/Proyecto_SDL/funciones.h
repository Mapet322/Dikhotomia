#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void iniciarSDL() {
    SDL_Init( SDL_INIT_EVERYTHING );
    screen = SDL_SetVideoMode( SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_SWSURFACE );
    SDL_WM_SetCaption( "Dikhotomia", NULL );
}

SDL_Surface* cargarImagen(const char direccion[50]) {
    SDL_Surface* imagen = NULL;
    SDL_Surface* optimizada = NULL;

    imagen = SDL_LoadBMP(direccion);
    if(imagen != NULL) {
        optimizada = SDL_DisplayFormat(imagen);
        SDL_FreeSurface(imagen);
    }

    if(optimizada == NULL) {
        cout << "fallo carga de imagen" << direccion << endl;
    }
    Uint32 colorkey = SDL_MapRGB(optimizada->format, 0, 0, 0);
    SDL_SetColorKey(optimizada, SDL_SRCCOLORKEY, colorkey);

    return optimizada;
}

void aplicarSuperficie(int x, int y, SDL_Surface* imagen, SDL_Surface* destino, SDL_Rect *clip = NULL) {
    SDL_Rect offset;
    offset.x = x;
    offset.y = y;
    SDL_BlitSurface(imagen, clip, destino, &offset);
}

void BRUT() {

}

void HARD() {

}

void MENU() {
    SDL_Surface* menu = NULL;
    SDL_Surface* brut = NULL;
    SDL_Surface* hard = NULL;
    SDL_Surface* exit = NULL;
    menu = cargarImagen("graphics\\menu\\mainmenu.bmp");
    brut = cargarImagen("graphics\\menu\\botonbrut.bmp");
    hard = cargarImagen("graphics\\menu\\botonhard.bmp");
    exit = cargarImagen("graphics\\menu\\botonexit.bmp");
    objeto botonbrut, botonhard, botonexit;
    botonbrut.set_posx(300);
    botonhard.set_posx(540);
    botonexit.set_posx(420);
    botonbrut.set_posy(300);
    botonhard.set_posy(300);
    botonexit.set_posy(420);
    SDL_Rect clip[2];
    botonbrut.set_estado(0);
    botonhard.set_estado(0);
    botonexit.set_estado(0);
    clip[0].h = 50;
    clip[0].w = 100;
    clip[0].x = 0;
    clip[0].y = 0;
    clip[1].h = 50;
    clip[1].w = 100;
    clip[1].x = 0;
    clip[1].y = 50;


    bool salir = false;

    while(salir == false) {
        aplicarSuperficie(0, 0, menu, screen);
        aplicarSuperficie(botonbrut.get_posx(), botonbrut.get_posy(), brut, screen, &clip[botonbrut.get_estado()]);
        aplicarSuperficie(botonhard.get_posx(), botonhard.get_posy(), hard, screen, &clip[botonhard.get_estado()]);
        aplicarSuperficie(botonexit.get_posx(), botonexit.get_posy(), exit, screen, &clip[botonexit.get_estado()]);
        SDL_Flip(screen);

        while(SDL_PollEvent(&evento)) {

            if(evento.type == SDL_QUIT) salir = true;

            if(evento.type == SDL_KEYDOWN) {

                switch(evento.key.keysym.sym) {
                case(SDLK_LEFT):
                    botonbrut.set_estado(1);
                    botonhard.set_estado(0);
                    botonexit.set_estado(0);
                    break;
                case(SDLK_RIGHT):
                    botonbrut.set_estado(0);
                    botonhard.set_estado(1);
                    botonexit.set_estado(0);
                    break;
                case(SDLK_DOWN):
                    botonbrut.set_estado(0);
                    botonhard.set_estado(0);
                    botonexit.set_estado(1);
                    break;
                case(SDLK_ESCAPE):
                    salir = true;
                case(SDLK_RETURN):
                    if(botonbrut.get_estado()) BRUT();
                    if(botonhard.get_estado()) HARD();
                    if(botonexit.get_estado()) salir = true;
                    break;
                default:
                    break;
                }
            }
        }

    }

    SDL_FreeSurface(menu);
    SDL_FreeSurface(brut);
    SDL_FreeSurface(exit);
    SDL_FreeSurface(hard);
}

#endif // FUNCIONES_H_INCLUDED
