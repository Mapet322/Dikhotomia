#ifndef VARGLOB_H_INCLUDED
#define VARGLOB_H_INCLUDED

const int SCREEN_WIDTH = 960;
const int SCREEN_HEIGHT = 540;
SDL_Surface* screen = NULL;
SDL_Event evento;

#endif // VARGLOB_H_INCLUDED
